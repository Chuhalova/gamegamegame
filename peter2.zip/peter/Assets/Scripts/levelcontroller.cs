﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class levelcontroller : MonoBehaviour {
	public static levelcontroller current;
	// Use this for initialization
	void Awake()
	{
		current = this;
	}
	Vector3 startingPosition;
	public void setStartPosition(Vector3 pos)
	{
		this.startingPosition = pos;
	}
	public void onPeterDeath(peter peter)
	{
		peter.transform.position = this.startingPosition;
	}
	// Update is called once per frame
	void Update () {
		
	}
}
