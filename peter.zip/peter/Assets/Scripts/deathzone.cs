﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class deathzone : MonoBehaviour {
	void OnTriggerEnter2D(Collider2D collider)
	{
		peter peter = collider.GetComponent<peter>();
		if (peter != null)
		{
			levelcontroller.current.onPeterDeath(peter);
		}
	}
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
