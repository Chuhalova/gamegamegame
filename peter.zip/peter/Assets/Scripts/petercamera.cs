﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class petercamera : MonoBehaviour {

	public peter peter;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		Transform peter_transform = peter.transform;
		Transform petercamera_transform = this.transform;

		Vector3 peter_position = peter_transform.position;
		Vector3 petercamera_position = petercamera_transform.position;

		petercamera_position.x = peter_position.x;
		petercamera_position.y = peter_position.y;

		petercamera_transform.position = petercamera_position;
	}
}
